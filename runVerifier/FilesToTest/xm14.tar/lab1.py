#!/bin/bash
python lab1.py $@